/**
 * File:   EmergencyList.cpp
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @version 2.0, September 17, 2014
 */

#include "EmergencyList.h"
#include "Patient.h"
#include <cstddef>
#include <cstdlib>
#include<iostream>
/* Creates a empty list*/
EmergencyList::EmergencyList(){
    first = NULL; 
    N=0;
}
/* Check if the Emergency list is empty or not and return a boolean value.*/
bool EmergencyList::Empty(){
    return first==NULL; 
}
/* Count the number of patients waiting.*/
int EmergencyList::Count(){
    return 0;
}
/* Admit a patient to the Emergency List based on the injury level.*/
void EmergencyList::AdmitNewPatient(string fname, string lname){
    /* Helps with the succesive randomization of rand.*/
    srand(time(NULL));
    int ranking=0;
    /* Generates a random number for the injury level for a patient.*/
    ranking = rand() % 10 + 1;
    /* Creates a new patient object.*/
    Patient newPatient(ranking, fname, lname); 
    /* Add the new patient to Patient Node. */
    PatientNode* newPatientNode = new PatientNode;
    newPatientNode->data=newPatient;
    newPatientNode->next=NULL;
    /* Node trailer in the list.*/
    PatientNode* previousPatientNode;
    /* The next node in the list.*/
    PatientNode* nextPatientNode;
    PatientNode* nodeHolder=first; 
    /*check if the first is pointing to a node.*/
    if(Empty()){
        first=newPatientNode;
        N++;
        return;
    }/* Check if the new patient injury level is less than the first patient*/    
    else if(newPatientNode->data.GetPatientRanking()<nodeHolder->data.GetPatientRanking()){
        newPatientNode->next=nodeHolder;
        first=newPatientNode;
    }/* Check if the new patient is greater than or equal first node.*/
    else{
        previousPatientNode=first;
        nextPatientNode=first->next;
        while(nextPatientNode!=NULL){
            if(nextPatientNode->data.GetPatientRanking()>newPatientNode->data.GetPatientRanking()){
                newPatientNode->next=nextPatientNode;
                previousPatientNode->next=newPatientNode;
                return;
            }
            if(nextPatientNode->data.GetPatientRanking()==newPatientNode->data.GetPatientRanking()){
                newPatientNode->next=nextPatientNode->next;
                previousPatientNode->next=newPatientNode;
                nextPatientNode->next=newPatientNode;
                return;
            }
            previousPatientNode=nextPatientNode;
            nextPatientNode=nextPatientNode->next;     
        } 
        previousPatientNode->next = newPatientNode;
        N++;        
    }
}
/* Attend to a patient*/
void EmergencyList::ReleaseAttendedPatient(){    
    if(Empty()){
        cout <<"The list is empty. Please use option 1 to insert a patient."<<endl;
        return;
    } 
    cout<<"Output from Option 2:"<<endl;
    cout<<"Attending to: "<<first->data.GetPatientFname()<<" "<<first->data.GetPatientLname()<<
            "\t"<<first->data.GetPatientRanking()<<endl;
    if(first->next==NULL){
        first=NULL;
        N--;
    }
    else{
        first=first->next;
        N--;
    }
}
/* Display the list of patients that are waiting in the emergency list.*/
void EmergencyList::DisplayWaitingList(){
    PatientNode* waitingPatient=first;
    if (Empty()) {
        cout << "The list is empty. Please use option 1 to insert a patient." << endl;
        return;
    }
    cout << "List of patients waiting:"<<endl; 
    //traverse the list until no more nodes are present
    while (waitingPatient!= NULL){ 
        
        cout << waitingPatient->data.GetPatientFname()<<" "
                <<waitingPatient->data.GetPatientLname()<<"\t"
                <<waitingPatient->data.GetPatientRanking()<<endl;
        //increment to the next node in the list
        waitingPatient = waitingPatient->next;
    }
    cout << endl;  
}

