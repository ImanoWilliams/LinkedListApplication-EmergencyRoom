/**
 * File:   Patient.cpp
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @version 1.1, September 17, 2014
 */
#include<string>
#include "Patient.h"
#include <cstddef>
#include <cstdlib>
#include<iostream>
/*
 * Class to implement the methods of patient.
 * Some of these methods were not use.
 */
/* Create a default patient object.*/
Patient::Patient(){
    patient_ranking=0;
    patient_fname="";
    patient_lname="";
}
/* Create a patient object by getting the user inputs.*/
Patient::Patient(int rank, string fname, string lname){
    patient_ranking=rank;
    patient_fname=fname;
    patient_lname=lname;
}
/* Set the patient's injury level*/
void Patient::SetPatientRanking(int rank){
    patient_ranking=rank;
}
/* Set the patient's first name.*/
void Patient::SetPatientFname(string fname){
    patient_fname=fname;
}
/* Set the patient's last name.*/
void Patient::SetPatientLname(string lname){
    patient_lname=lname;
}
/* Get the patient's injury level.*/
int Patient::GetPatientRanking(){
    return patient_ranking;
}
/* Get the patient's first name.*/
string Patient::GetPatientFname(){
    return patient_fname;
}
/* Get the patient's last name.*/
string Patient::GetPatientLname(){
    return patient_lname;
}

