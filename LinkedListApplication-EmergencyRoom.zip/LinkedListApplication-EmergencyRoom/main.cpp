/**
 * File:   main.cpp
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @version 1.0, September 16, 2014
 */

#include "EmergencyList.h"
#include "Patient.h"
#include <cstdlib>
#include <string>
#include<iostream>

using namespace std;
/*
 * Class to assist the hospital with ordering of patients based on the seriousness
 * of a patient's injury. The user has the option of admitting to the hospital,
 * attend to a patient, display the patients waiting to be attended to and also to
 * end the program.
 */
int main(int argc, char** argv) {
    int UserInput = 0;    
    EmergencyList MyEmergencyList;       
    cout<<"Option 1. Allows a user to admit a New Patient."<<endl;
    cout<<"Option 2. Allows a user to attend to most seriously ill patient."<<endl;
    cout<<"Option 3. Print Emergency waiting list."<<endl;
    cout<<"Option 4. Exit Program."<<endl; 
    cout<<"**************************************************"<<endl; 
    cout<<"**WARNINGS**"<<endl;
    cout<<"Application does not allow for number(s) to be in a name.\n"
          "Also, names cannot start with a special character."<<endl;    
    cout<<"**************************************************"<<endl;    
    while(UserInput!=4){
        cout<<"Enter Option 1-4:";
        //continuously prompts the user if input is not an Integer          
        while (!(cin >> UserInput)){ 
            cout << "Please follow the instruction and enter Option 1-4 .";
            cin.clear(); 
            cin.ignore(1000, '\n'); 
        }         
        /* Process the User input.*/
        switch (UserInput){
            /* Insert new patient*/
            case 1:{
                string fname="";
                string lname="";
                bool checkfname=true;
                bool checklname=true; 
                cout<<"Enter first name of new patient.";                
                /*continuously prompts the user if name is invalid
                 * empty.                 
                 */ 
                while(checkfname){
                    cin>>fname;
                    /* Check if name is empty or less than four characters.*/
                    if (fname == ""||(fname.length()<4)){
                        cout<<"First name cannot be less than 4 characters."; 
                        checklname = true;  
                    }
                    else{
                        for(int i=0;i<fname.length();i++){
                            /* check is name is a number or it begins with a special character.*/
                            if(isdigit(fname.at(i))||(!isalpha(fname.at(0)))){
                               cout<<"First name should not have any numbers.\n"
                                       "or the first letter is a special character." <<endl<<endl;
                               cout<<"Please enter a valid first name.";
                               checkfname=true;
                               break;
                            }
                            checkfname = false; 
                        }                        
                    }  
                }                
                cout<<"Enter last name of new patient.";
                //continuously prompts the user if name is invalid  
                while(checklname){
                    cin>>lname; 
                    /* Check if name is empty or less than four characters.*/
                    if (lname == ""||(lname.length()<4)){
                        cout<<"Last name cannot be less than 4 characters.";
                        checklname = true;    
                    }
                    else{
                        for(int i=0;i<lname.length();i++){
                            /* check is name is a number or it begins with a special character.*/
                            if(isdigit(lname.at(i))||(!isalpha(lname.at(0)))){
                               cout<<"Last name should not have any numbers\n"
                                       "or the first letter is a special character." <<endl<<endl;
                               cout<<"Please enter a valid last name.";
                               checklname=true;
                               break;
                            }
                            checklname = false; 
                        }                        
                    }  
                }                 
                MyEmergencyList.AdmitNewPatient(fname,lname);
                break;
            } 
            /* Attend to patient.*/
            case 2:{             
                MyEmergencyList.ReleaseAttendedPatient();
                break;
            }
            /* Display patients waiting.*/
            case 3:{
                MyEmergencyList.DisplayWaitingList();
                break;  
            }
            /* End program.*/
            case 4:
                break;        
            default:
                cout << "\nNot a valid Number/Option."<<endl;
        }
    } 
    return 0;
}


