/* 
 * File:   Patient.h
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @version 1.1, September 17, 2014
 */
#include <cstddef>
#include <cstdlib>
#include<iostream>
using namespace std;
/**
 * Class to represent a patient in the hospital.
 * Some of these methods were not use.
 */
#ifndef PATIENT_H
#define	PATIENT_H
class Patient{
private:
    /* Variable to store the level of seriousness of a patients injury.*/
    int patient_ranking;
    /* Variables to store the first and last name of patient.*/
    string patient_fname,patient_lname;
public:
    /* create default patient object*/
    Patient();
    /* Creates a patient object with specified values.*/
    Patient(int, string, string);
    /* Setters and Getters of the attributes of a patients.*/
    void SetPatientRanking(int);
    void SetPatientFname(string);
    void SetPatientLname(string); 
    int GetPatientRanking();
    string GetPatientFname();
    string GetPatientLname();    
};
#endif	/* PATIENT_H */

