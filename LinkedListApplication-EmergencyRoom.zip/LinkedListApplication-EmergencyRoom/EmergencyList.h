/* 
 * File:   EmergencyList.h
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @version 1.2, September 12, 2014
 */ 

#include "Patient.h"
using namespace std;
/*
 * Class to represent how the hospital is going to serve the patients.
 */

#ifndef EMERGENCYLIST_H
#define	EMERGENCYLIST_H
/* Patient type*/
typedef Patient ElementType;

struct PatientNode{  
    /* Patient type object.*/
    ElementType data; 
    /* Node pointer to the store the address of the next Patient Node in the list.*/
    PatientNode* next;
};
class EmergencyList{
    public:
        EmergencyList(); //Create an empty list
        bool Empty(); // return true if the list is empty, otherwise return false
        void AdmitNewPatient(string fname, string lname); //insert a value x keeping the list in numeric order
        void ReleaseAttendedPatient(); //if value x is in the list, remove x
        void DisplayWaitingList(); //Display the data values in the list	
        int Count(); //return the number of items currently on the list         

    private:
        int N; //number of values in list
        PatientNode * first; //Pointer to the first element of the list        
};
#endif	/* EMERGENCYLIST_H */

